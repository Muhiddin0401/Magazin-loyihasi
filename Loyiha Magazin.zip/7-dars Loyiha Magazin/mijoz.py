import sqlite3

class Mijoz:
    def __init__(self, db_nom="do'kon.db"):
        self.aloqa = sqlite3.connect(db_nom)
        self.kursor = self.aloqa.cursor()
        self.jadval_yaratish()

    def jadval_yaratish(self):
        self.kursor.execute('''
        CREATE TABLE IF NOT EXISTS mijozlar (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ism TEXT NOT NULL,
            telefon TEXT NOT NULL UNIQUE
        )
        ''')
        self.aloqa.commit()

    def mijoz_qoshish(self, ism, telefon):
        try:
            self.kursor.execute("INSERT INTO mijozlar (ism, telefon) VALUES (?, ?)", (ism, telefon))
            self.aloqa.commit()
            print(f"Mijoz '{ism}' qo'shildi!")
        except sqlite3.IntegrityError:
            print("Bunday telefon raqam bilan mijoz allaqachon mavjud.")

    def mijozlarni_korish(self):
        self.kursor.execute("SELECT * FROM mijozlar")
        mijozlar = self.kursor.fetchall()
        print("Mijozlar ro'yxati:")
        for mijoz in mijozlar:
            print(f"ID: {mijoz[0]}, Ismi: {mijoz[1]}, Telefon: {mijoz[2]}")

    def mijoz_ochirish(self, mijoz_id):
        self.kursor.execute("DELETE FROM mijozlar WHERE id = ?", (mijoz_id,))
        self.aloqa.commit()
        print(f"Mijoz ID {mijoz_id} o'chirildi!")

    def yopish(self):
        self.aloqa.close()