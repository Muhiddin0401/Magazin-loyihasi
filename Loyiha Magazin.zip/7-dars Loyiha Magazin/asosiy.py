from ombor import Ombor
from mijoz import Mijoz

class SavdoBoshqaruvi:
    def __init__(self):
        self.ombor = Ombor()
        self.mijoz = Mijoz()

    def asosiy_menyu(self):
        while True:
            print("\n--- Tizim menyusi ---")
            print("1. Mahsulot qo'shish")
            print("2. Mijoz qo'shish")
            print("3. Mahsulotlarni ko'rish")
            print("4. Mijozlarni ko'rish")
            print("5. Mahsulotni o'chirish")
            print("6. Mijozni o'chirish")
            print("0. Chiqish")

            tanlov = input("Tanlovni kiriting: ")

            if tanlov == "1":
                nom = input("Mahsulot nomi: ")
                narx = float(input("Mahsulot narxi: "))
                miqdor = int(input("Mahsulot miqdori: "))
                self.ombor.mahsulot_qoshish(nom, narx, miqdor)
            elif tanlov == "2":
                ism = input("Mijoz ismi: ")
                telefon = input("Mijoz telefoni: ")
                self.mijoz.mijoz_qoshish(ism, telefon)
            elif tanlov == "3":
                self.ombor.mahsulotlarni_korish()
            elif tanlov == "4":
                self.mijoz.mijozlarni_korish()
            elif tanlov == "5":
                mahsulot_id = int(input("O'chirish uchun mahsulot ID'sini kiriting: "))
                self.ombor.mahsulot_ochirish(mahsulot_id)
            elif tanlov == "6":
                mijoz_id = int(input("O'chirish uchun mijoz ID'sini kiriting: "))
                self.mijoz.mijoz_ochirish(mijoz_id)
            elif tanlov == "0":
                print("Tizimdan chiqildi.")
                break
            else:
                print("Noto'g'ri tanlov. Iltimos, qaytadan urinib ko'ring.")

    def yopish(self):
        self.ombor.yopish()
        self.mijoz.yopish()

if __name__ == "__main__":
    savdo = SavdoBoshqaruvi()
    try:
        savdo.asosiy_menyu()
    finally:
        savdo.yopish()
