import sqlite3

class Ombor:
    def __init__(self, db_nom="do'kon.db"):
        self.aloqa = sqlite3.connect(db_nom)
        self.kursor = self.aloqa.cursor()
        self.jadval_yaratish()

    def jadval_yaratish(self):
        self.kursor.execute('''
        CREATE TABLE IF NOT EXISTS mahsulotlar (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nom TEXT NOT NULL,
            narx REAL NOT NULL,
            miqdor INTEGER NOT NULL
        )
        ''')
        self.aloqa.commit()

    def mahsulot_qoshish(self, nom, narx, miqdor):
        self.kursor.execute("INSERT INTO mahsulotlar (nom, narx, miqdor) VALUES (?, ?, ?)", (nom, narx, miqdor))
        self.aloqa.commit()
        print(f"Mahsulot '{nom}' qo'shildi!")

    def mahsulotlarni_korish(self):
        self.kursor.execute("SELECT * FROM mahsulotlar")
        mahsulotlar = self.kursor.fetchall()
        print("Mahsulotlar ro'yxati:")
        for mahsulot in mahsulotlar:
            print(f"ID: {mahsulot[0]}, Nomi: {mahsulot[1]}, Narxi: {mahsulot[2]}, Miqdori: {mahsulot[3]}")

    def mahsulot_ochirish(self, mahsulot_id):
        self.kursor.execute("DELETE FROM mahsulotlar WHERE id = ?", (mahsulot_id,))
        self.aloqa.commit()
        print(f"Mahsulot ID {mahsulot_id} o'chirildi!")

    def yopish(self):
        self.aloqa.close()